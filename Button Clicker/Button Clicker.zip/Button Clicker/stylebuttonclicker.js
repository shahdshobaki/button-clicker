
function changeMe(element){
element.innerText= "logout";
}

function removeMe(element){
    element.remove();
}
function likeMe(element){
    alert("Ninja was liked");
}